# YOLOv11 on Raspberry Pi 5

This repository contains training, benchmarking, and deployment scripts for YOLOv11 object detection on Raspberry Pi 5.