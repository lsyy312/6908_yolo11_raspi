# sample_images folder
